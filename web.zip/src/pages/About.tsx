import React from 'react';
import { ShoppingBag, Monitor, Palette, User, ArrowRight } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="w-full bg-dark-bg text-white flex flex-col font-sans">
      
      {/* 1. Header Section */}
      <section className="min-h-[100dvh] flex flex-col items-center justify-center text-center px-4 pt-16">
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight mb-4 uppercase">
          Always Beta
        </h1>
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-16">
          <span className="border-b-[4px] md:border-b-[6px] border-white pb-2 lg:pb-4 inline-block">
            The Logic of Growth
          </span>
        </h1>
        
        <h2 className="text-3xl md:text-5xl lg:text-6xl font-bold tracking-tight mt-12 mb-4 break-keep text-gray-300">
          완성에 머무르지 않고
        </h2>
        <h2 className="text-3xl md:text-5xl lg:text-6xl font-bold tracking-tight break-keep text-white">
          <span className="border-b-[4px] md:border-b-[6px] border-white pb-2 lg:pb-4 inline-block">
            언제나 혁신하며 진화합니다
          </span>
        </h2>
      </section>

      {/* 2. Manifesto Section */}
      <section className="min-h-[100dvh] w-full bg-[#111111] flex flex-col items-center justify-center text-center border-y border-white/5 px-4 md:px-6 py-20">
        <div className="text-lg md:text-2xl lg:text-3xl text-gray-300 leading-[2.2] md:leading-[2.5] max-w-6xl font-light break-keep space-y-16 md:space-y-24">
          <p>
            건축디자인과 도시계획을 하며 물리적인 환경을 다루는 법을 배웠습니다.<br className="hidden md:block"/>
            그러다 우연히 접한 디지털트윈과 스마트시티의 세계는 저를 로보틱스라는 새로운 도전으로 이끌었습니다.
          </p>
          <p>
            공간을 채우는 것을 넘어, 그 안에서 스스로 움직이며 가치를 창출하는 로봇의 가능성에 매료되었고<br className="hidden md:block"/>
            그 분야의 <span className="text-white font-medium">"일원"</span>이 되고 싶었습니다.
          </p>
          <p>
            익숙한 <span className="text-white font-medium">"과거"</span>를 내려놓고 로보틱스 엔지니어로의 길을 걷고 있는 지금,<br className="hidden md:block"/>
            저는 어느 때보다 빠르게 성장하고 있습니다.<br className="hidden md:block"/>
            시대의 흐름에 뒤쳐지지 않고, 기술로 일상을 개선하는 실질적인 결과물을 만드는 개발자가 되고자 합니다.
          </p>
        </div>
      </section>

      

      {/* 3. Solutions Section (with abstract overlay effect) */}
      <section className="relative py-24 md:py-32 px-6 overflow-hidden">
        {/* Background Image / Gradient placeholder */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#1a1a1a] to-[#0a0a0a] z-0"></div>
        {/* Colorful blur effect to simulate the image bg in the reference */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-yellow-500/20 rounded-full blur-[120px] pointer-events-none z-0"></div>

        <div className="relative z-10 max-w-6xl mx-auto flex flex-col items-center">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 text-center">
            Skills
          </h2>
          <p className="text-gray-400 text-lg md:text-xl mb-20 text-center">
            {/* 성공적인 디지털 비즈니스를 위한 고객 맞춤 솔루션 */}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8 w-full">
            {/* Column 1 */}
            <div className="flex flex-col">
              <h3 className="text-2xl font-bold mb-4 uppercase tracking-wider relative inline-block">
                Development
              </h3>
              <div className="w-full h-px bg-white/30 mb-6"></div>
              <ul className="text-gray-400 space-y-3 font-light">
                <li>- Python</li>
                <li>- C++</li>
              </ul>
            </div>

            {/* Column 2 */}
            <div className="flex flex-col">
              <h3 className="text-2xl font-bold mb-4 uppercase tracking-wider relative inline-block">
                Robotics
              </h3>
              <div className="w-full h-px bg-white/30 mb-6"></div>
              <ul className="text-gray-400 space-y-3 font-light">
                <li>- ROS2</li>
                <li>- Isaac Sim</li>
                <li>- Moveit2</li>
                <li>- Nav2</li>
              </ul>
            </div>

            {/* Column 3 */}
            <div className="flex flex-col">
              <h3 className="text-2xl font-bold mb-4 uppercase tracking-wider relative inline-block">
                AI & Computer Vision
              </h3>
              <div className="w-full h-px bg-white/30 mb-6"></div>
              <ul className="text-gray-400 space-y-3 font-light">
                <li>- YOLO</li>
                <li>- OpenCV</li>
              </ul>
            </div>

            {/* Column 3 */}
            <div className="flex flex-col">
              <h3 className="text-2xl font-bold mb-4 uppercase tracking-wider relative inline-block">
                3D Modeling & Planning
              </h3>
              <div className="w-full h-px bg-white/30 mb-6"></div>
              <ul className="text-gray-400 space-y-3 font-light">
                <li>- Sketchup</li>
                <li>- Blender</li>
                <li>- Auto CAD</li>
                <li>- Qgis</li>
              </ul>
            </div>

            {/* Column 4 */}
            <div className="flex flex-col">
              <h3 className="text-2xl font-bold mb-4 uppercase tracking-wider relative inline-block">
                Graphic Design
              </h3>
              <div className="w-full h-px bg-white/30 mb-6"></div>
              <ul className="text-gray-400 space-y-3 font-light">
                <li>- Photoshop</li>
                <li>- Illustrator</li>
                
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Clients Section */}
      <section className="py-24 px-6 bg-dark-bg text-center flex flex-col items-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-4 uppercase tracking-tight">
          OUR CLIENTS
        </h2>
        <p className="text-gray-400 text-lg mb-16 max-w-xl mx-auto font-light">
          이목디자인은 많은 클라이언트와 함께하며 다양한 경험으로 성공적인 프로젝트를 수행합니다.
        </p>

        {/* Client Logos Placeholder Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12 max-w-5xl mx-auto w-full opacity-70">
          {[
            'SONGZIO', 'SBXG', 'ZIOSONGZIO', 'MAILIN',
            'BICYCLE', 'BEAUND', 'Celligram', 'BDNS',
            'ZZERO', 'Horme', 'SIEG', 'UNIVERSAL',
            'UNGIMMICK', 'MOUSE POTATO', 'ARU CHEUM', 'TI E LA'
          ].map((client, idx) => (
            <div key={idx} className="flex items-center justify-center py-6 px-4 bg-[#111] rounded-lg border border-white/5 hover:border-white/20 transition-colors">
              <span className="text-lg md:text-xl font-bold uppercase tracking-wider text-gray-500">
                {client}
              </span>
            </div>
          ))}
        </div>
      </section>
      
    </div>
  );
};

export default About;